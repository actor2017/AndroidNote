package com.sxpb.tianhang;

import android.graphics.Bitmap;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * 作用: {1， 2， 3，}
 * 作者：liuyiyuan
 * 日期：2016/11/10 11:07
 * 邮箱：liuyiyuan@xnihuamm.net
 * weixin: Dkalan
 */

public class LiuyyWebViewClient extends WebViewClient {
    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        super.onPageStarted(view, url, favicon);
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
    }
}
