package com.sxpb.tianhang;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;

import utils.ImageUtil;

/**
 * (1) 工大附中url=http://bp.zgdfs.com:8181/PhoneApp；
 * （2）默认app地址：http://114.55.129.50:9408/jump.aspx？deviceId=?
 */
public class WebActivity extends AppCompatActivity implements LiuyyWebChromeClient.OpenFileChooserCallBack {


    private WebView webView;
    private String url;  //目标url

    private final int WRITE_EXTERNAL_STORAGE_REQUEST_CODE=100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        webView = (WebView) findViewById(R.id.webView);
        initHtml5LocalCache(this,webView);
        webView.setWebChromeClient(new LiuyyWebChromeClient(this));
        webView.setWebViewClient(new LiuyyWebViewClient());

        //Bundle bundle = this.getIntent().getExtras();

        //url = "http://10.4.12.7:9408/jump.aspx?deviceId=" + getIMEI(this);
        //url = "http://114.55.129.50:9408/jump.aspx?deviceId=" + getIMEI(this);

        // 智慧校园 http://bp.zgdfs.com:8181/PhoneApp
        // 三项评比 http://120.26.42.181:8007/index.html
        /**
         * 内网地址： http://10.4.12.7:1008/index.html
         * 公网地址：http://120.26.42.181:8007/index.html
         */
        url = "http://120.26.42.181:8007/index.html";
        webView.loadUrl(url);

    }

    /**
     * WebView对HTML5的支持配置
     *
     * @param context
     */
    private void initHtml5LocalCache(Context context,WebView webView) {

        // HTML5支持的配置
        WebSettings webSettings = webView.getSettings();

        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("utf-8");
        webSettings.setBuiltInZoomControls(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setAllowFileAccess(true);  //设置可以访问文件
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true); //支持通过JS打开新窗口
        webSettings.setLoadsImagesAutomatically(true);  //支持自动加载图片
        webSettings.setUseWideViewPort(true);  //将图片调整到适合webview的大小

        // pc网页屏幕自动适配
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        //支持多窗口模式
        webSettings.supportMultipleWindows();
        //html的支持

        webSettings.setSavePassword(false);
        webSettings.setSaveFormData(false);


        // 启用数据库
        webSettings.setDatabaseEnabled(true);
        String dir = context.getApplicationContext()
                .getDir("database", Context.MODE_PRIVATE).getPath();
        // 设置数据库路径
        webSettings.setDatabasePath(dir);
        // 使用localStorage则必须打开
        webSettings.setDomStorageEnabled(true);
        // 启用地理定位
        webSettings.setGeolocationEnabled(true);
        // 设置定位的数据库路径
        webSettings.setGeolocationDatabasePath(dir);

    }

    /**
     * 按键响应，在WebView中查看网页时，按返回键的时候按浏览历史退回,如果不做此项处理则整个WebView返回退出
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Check if the key event was the Back button and if there's history
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            // 返回键退回
            webView.goBack();
            return true;
        }
        // If it wasn't the Back key or there's no web page history, bubble up
        // to the default
        // system behavior (probably exit the activity)
        return super.onKeyDown(keyCode, event);
    }

    /**
     * 获取手机ID
     *
     * @param context 上下文对象
     * @return 手机的ID
     */
    public static String getIMEI(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private ValueCallback<Uri> mValueCallback;
    private ValueCallback<Uri[]> mValueCallbackAndroid5;

    private static final int REQUEST_CODE_PICK_IMAGE = 0;
    private static final int REQUEST_CODE_IMAGE_CAPTURE = 1;
    private Intent mSourceIntent;



    public void showOptions() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setOnCancelListener(new ReOnCancelListener());
        alertDialog.setTitle("选择图片");
        alertDialog.setItems(new String[]{"相机选取","拍照","取消"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            mSourceIntent = ImageUtil.choosePicture();
                            startActivityForResult(mSourceIntent, REQUEST_CODE_PICK_IMAGE);
                        }
                        else if(which==1) {
                            mSourceIntent = ImageUtil.takeBigPicture();
                            startActivityForResult(mSourceIntent, REQUEST_CODE_IMAGE_CAPTURE);
                        }
                        else
                        {
                            dialog.dismiss();
                            dialog.cancel();
                        }
                    }
                }
        );
        alertDialog.show();
    }

    //检车读写文件 拍照像个权限
    private boolean checkRights(){
        if (ActivityCompat.checkSelfPermission(WebActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
                ||ActivityCompat.checkSelfPermission(WebActivity.this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            //申请WRITE_EXTERNAL_STORAGE权限
            ActivityCompat.requestPermissions(WebActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA},
                    WRITE_EXTERNAL_STORAGE_REQUEST_CODE);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==WRITE_EXTERNAL_STORAGE_REQUEST_CODE&&grantResults!=null)
        {
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED&&grantResults[1]==PackageManager.PERMISSION_GRANTED)
            {
                // do next
                showOptions();
            }
            else
            {
                Toast.makeText(this,"部分权限申请失败，无法进行下一步的操作",Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    public void openFileChooserCallBack(ValueCallback<Uri> uploadMsg, String acceptType) {
        mValueCallback=uploadMsg;
        if(checkRights())
        {
            showOptions();
        }
    }

    @Override
    public void openFileChooserCallBackAndroid5(ValueCallback<Uri[]> uploadMsg, String acceptType) {
        mValueCallbackAndroid5=uploadMsg;
        if(checkRights())
        {
            showOptions();
        }
    }

    private class ReOnCancelListener implements DialogInterface.OnCancelListener {

        @Override
        public void onCancel(DialogInterface dialogInterface) {
            if (mValueCallback != null) {
                mValueCallback.onReceiveValue(null);
                mValueCallback = null;
            }

            if(mValueCallbackAndroid5!=null)
            {
                mValueCallbackAndroid5.onReceiveValue(null);
                mValueCallbackAndroid5 = null;
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        switch (requestCode) {
            case REQUEST_CODE_IMAGE_CAPTURE:
            case REQUEST_CODE_PICK_IMAGE: {
                try {
                    if (mValueCallback == null&&mValueCallbackAndroid5==null) {
                        return;
                    }
                    String sourcePath = ImageUtil.retrievePath(this, mSourceIntent, data);
                    if (TextUtils.isEmpty(sourcePath) || !new File(sourcePath).exists()) {
                        Log.w("WebActivity", "sourcePath empty or not exists.");
                        break;
                    }
                    Uri uri = Uri.fromFile(new File(sourcePath));
                    if(mValueCallback!=null)
                    {
                        mValueCallback.onReceiveValue(uri);
                    }

                    if(mValueCallbackAndroid5!=null)
                    {
                        mValueCallbackAndroid5.onReceiveValue(new Uri[]{uri});
                    }

                    //通知更新图库
                    if(requestCode==REQUEST_CODE_IMAGE_CAPTURE)
                    {
                        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,uri));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }
}
