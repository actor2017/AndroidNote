package com.sxpb.tianhang;

import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/**
 * 作用: {1， 自定的实现webView拍照上传的工具类}
 * 作者：liuyiyuan
 * 日期：2016/11/10 10:48
 * 邮箱：liuyiyuan@xnihuamm.net
 * weixin: Dkalan
 */

public class LiuyyWebChromeClient extends WebChromeClient {

    public interface OpenFileChooserCallBack {
        void openFileChooserCallBack(ValueCallback<Uri> uploadMsg, String acceptType);
        void openFileChooserCallBackAndroid5(ValueCallback<Uri[]> uploadMsg, String acceptType);
    }

    private OpenFileChooserCallBack mOpenFileChooserCallBack;  //选择图片回调接口

    public LiuyyWebChromeClient(OpenFileChooserCallBack mOpenFileChooserCallBack)
    {
        this.mOpenFileChooserCallBack=mOpenFileChooserCallBack;
    }

    //For Android 3.0+
    public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType) {
        mOpenFileChooserCallBack.openFileChooserCallBack(uploadMsg, acceptType);
    }


    // For Android < 3.0
    public void openFileChooser(ValueCallback<Uri> uploadMsg) {
        openFileChooser(uploadMsg, "");
    }


    // For Android  > 4.1.1
    public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
        openFileChooser(uploadMsg, acceptType);
    }


    // For Android > 5.0
    @Override
    public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> uploadMsg, WebChromeClient.FileChooserParams
            fileChooserParams) {
        mOpenFileChooserCallBack.openFileChooserCallBackAndroid5(uploadMsg,"");
        return true;
    }


}
