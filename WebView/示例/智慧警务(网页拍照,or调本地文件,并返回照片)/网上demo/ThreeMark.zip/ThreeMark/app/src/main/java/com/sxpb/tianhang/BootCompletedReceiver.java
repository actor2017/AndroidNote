package com.sxpb.tianhang;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.sxpb.tianhang.WebActivity;

/**
 * 作用: {1， 2， 3，}
 * 作者：liuyiyuan
 * 日期：2016/8/24 11:13
 * 邮箱：liuyiyuan@xnihuamm.net
 * weixin: Dkalan
 */
public class BootCompletedReceiver extends BroadcastReceiver {

    static final String ACTION = "android.intent.action.BOOT_COMPLETED";
    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals(ACTION))
        {
            Intent sayHelloIntent=new Intent(context,WebActivity.class);
            sayHelloIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(sayHelloIntent);
        }
    }
}
