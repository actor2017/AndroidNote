package com.itheima.androidl.fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import com.itheima.androidl.R;
public abstract class BaseFragment extends Fragment {

	protected View mRootView;
	protected View mDemoView;
	protected WebView mWebView;
	protected boolean isDemoShow = true;

	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		if (mRootView == null) {
			mRootView = initView();
			mDemoView = mRootView.findViewById(R.id.demo);
			mWebView = (WebView) mRootView.findViewById(R.id.web);
			mWebView.getSettings().setDisplayZoomControls(false);
			mWebView.loadUrl(getUrl());
		}
		refreshView();
		//Toast.makeText(getActivity(), isDemoShow + "", Toast.LENGTH_SHORT).show();
		return mRootView;
	}

	/**
	 * 子类重写
	 * 初始化子类布局
     */
	protected abstract View initView();

	/**
	 * 点击切换教程和案例
	 */
	protected void refreshView() {
		mDemoView.setVisibility(isDemoShow ? View.VISIBLE : View.INVISIBLE);
		mWebView.setVisibility(isDemoShow ? View.INVISIBLE : View.VISIBLE);
	}

	/**
	 * 右上角 使用教程按钮
	 * 点击切换教程和案例
     */
	public boolean onOptionsItemSelected(MenuItem menu) {
		if (menu.getItemId() == R.id.action_example) {
			isDemoShow = !isDemoShow;
			refreshView();
			return true;
		}
		return false;
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

	public abstract String getUrl();
}
